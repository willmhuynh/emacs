---
name: Bug Report
about: Something's not working.
title: ''
labels: ''
assignees: 'jethrokuan'
---

### Description

#### Steps to Reproduce
<!--
Example:

1. Load Emacs
2. Run `org-roam--build-cache-async`
3. Run `org-roam-find-file`
...
-->


#### Expected Results
<!-- Example: File A is there -->

#### Actual Results
<!-- Example: File A is missing -->

### Versions
- Emacs (`C-h v emacs-version`): vX.X.X
- Org-roam commit: https://github.com/jethrokuan/org-roam/commit/commithashhere
