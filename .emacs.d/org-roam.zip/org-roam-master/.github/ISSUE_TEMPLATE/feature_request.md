---
name: Feature Request
about: Create a feature request to improve Org-roam
title: ''
labels: 'enhancement'
assignees: 'jethrokuan'
---

### Brief Abstract

### Long Description

### Proposed Implementation (if any)

### Please check the following:
- [ ] No similar feature requests
