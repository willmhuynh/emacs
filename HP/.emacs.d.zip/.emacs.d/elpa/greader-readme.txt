Usage:

In order to use greader, you have to install either espeak and/or
speech-dispatcher and, in case of speech-dispatcher, it has to work.

If external packages work properly, using greader is easy:
'M-x greader-mode <ret>'
In the mode line appears "greader".

Then you press 'C-r <spc>' and greader starts reading, moving the
cursor at the start of the sentence it is reading at the moment.

To stop reading, just press '<spc>'.

If you want to change the language in which the text is spoken, press
'C-r l', and when asked to new language, digit the language iso code.
If you want to cycle throwgh available back-ends, you have to press
'C-r b'. With a prefix arg, this command asks you to type a back-end
name.

Other features:
You can set a timer, enabling it with 'C-r t'.

With timer enabled, greader will read for time set in "greader-timer"
variable, which is customizable.

You can set a timer locally in the buffer you are reading with 'M-x greader-set-timer':
Timer is expressed in minutes.

There is a variant of the timer feature, called "greader-tired-mode",
in which, when timer expires, and you don't press a key for a
customizable amount of seconds, greader will position the pointer at
last position when you pressed 'C-r <spc>'.

To enable tired mode, you have to press 'C-r s'.

More features are coming!
