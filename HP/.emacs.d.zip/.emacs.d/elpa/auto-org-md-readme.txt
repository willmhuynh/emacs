auto-org-md.el exports a markdown-file automatically when you save
an org-file.
