TODO: documentation

TODO: get card types from anki

TODO: list/edit existing cards?

TODO: look at cloze stuff again

TODO: testing with hash tables?
